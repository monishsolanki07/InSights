package com.monish.insight

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.Scaffold
import androidx.navigation.compose.rememberNavController
import com.monish.insight.ui.navigation.BottomBar
import com.monish.insight.ui.navigation.BottomNavGraph
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.padding

import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.monish.insight.ui.home.HomeScreen
import com.monish.insight.ui.bookmarks.BookmarksScreen
import com.monish.insight.ui.profile.ProfileScreen
import com.monish.insight.ui.navigation.BottomBar

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val navController = rememberNavController()
            Scaffold(
                bottomBar = { BottomBar(navController = navController) }
            ) { innerPadding ->
                NavHost(
                    navController = navController,
                    startDestination = "home",
                    modifier = Modifier.padding(innerPadding)
                ) {
                    composable("home") { HomeScreen() }
                    composable("bookmarks") { BookmarksScreen() } // implement this
                    composable("profile") { ProfileScreen() } // placeholder
                }
            }

        }
    }
}
