package com.monish.insight.ui.bookmarks

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.monish.insight.data.local.BookmarkEntity
import com.monish.insight.data.repository.NewsRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class BookmarksViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = NewsRepository(application)

    val bookmarks = repository.getAllBookmarks()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    fun addBookmark(article: BookmarkEntity) {
        viewModelScope.launch {
            repository.insertBookmark(article)
        }
    }

    fun removeBookmark(article: BookmarkEntity) {
        viewModelScope.launch {
            repository.deleteBookmark(article)
        }
    }
}
