package com.monish.insight.ui.home

import android.app.Application
import android.util.Log
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.monish.insight.data.local.BookmarkEntity
import com.monish.insight.ui.bookmarks.BookmarksViewModel
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Alignment
import com.monish.insight.ui.home.ArticleItem



@Composable
fun HomeScreen(
    homeViewModel: HomeViewModel = viewModel(
        factory = androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory(
            LocalContext.current.applicationContext as Application
        )
    ),
    bookmarksViewModel: BookmarksViewModel = viewModel()
) {
    val newsArticles by homeViewModel.articles
    LaunchedEffect(newsArticles) {
        Log.d("HomeScreen", "Observed articles: ${newsArticles.size}")
        newsArticles.forEach { Log.d("HomeScreen", it.title ?: "No title") }
    }
    if (newsArticles.isEmpty()) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text(text = "No news available", style = MaterialTheme.typography.titleMedium)
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(8.dp)
        ) {
            items(newsArticles) { article ->
                ArticleItem(
                    title = article.title ?: "",
                    description = article.description ?: "",
                    imageUrl = article.urlToImage,
                    onBookmarkClick = {
                        val bookmark = BookmarkEntity(
                            title = article.title,
                            description = article.description,
                            url = article.url,
                            urlToImage = article.urlToImage,
                            publishedAt = article.publishedAt
                        )
                        bookmarksViewModel.addBookmark(bookmark)
                    }
                )
            }
        }
    }
}


@Composable
fun ArticleItem(
    title: String,
    description: String,
    onBookmarkClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(6.dp),
        elevation = CardDefaults.cardElevation(4.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(text = title, style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(6.dp))
            Text(text = description, style = MaterialTheme.typography.bodyMedium)
            Spacer(modifier = Modifier.height(8.dp))
            Button(onClick = { onBookmarkClick() }) {
                Text("Bookmark")
            }
        }
    }
}
